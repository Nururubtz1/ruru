<?php
$conn = mysqli_connect("localhost", "root", "", "db_prediksi_rumah");
$query = "SELECT * FROM riwayat_prediksi ORDER BY waktu_prediksi DESC";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - Riwayat AI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fa; }
        .table-custom { background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
    </style>
</head>
<body class="py-5">
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold"><i class="bi bi-database me-2 text-primary"></i> Database Riwayat Analisis</h3>
        <a href="index.php" class="btn btn-dark"><i class="bi bi-house me-1"></i> Kembali ke Kalkulator</a>
    </div>

    <div class="table-responsive table-custom">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Waktu Inspeksi</th>
                    <th>Spesifikasi (LT/LB/KT/U)</th>
                    <th>Estimasi Harga AI</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td class="fw-bold">#<?php echo $row['id']; ?></td>
                    <td><?php echo $row['waktu_prediksi']; ?></td>
                    <td><?php echo $row['luas_tanah'] . "m² / " . $row['luas_bangunan'] . "m² / " . $row['kamar_tidur'] . " Kmr / " . $row['umur_rumah'] . " Thn"; ?></td>
                    <td class="fw-bold text-success">Rp <?php echo number_format($row['harga_prediksi'], 0, ',', '.'); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>