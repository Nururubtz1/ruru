<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Properti Analitik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { 
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .glass-card:hover { transform: translateY(-5px); }
        .form-control {
            border-radius: 10px;
            padding: 12px 15px;
            border: 1px solid #ced4da;
            transition: all 0.3s;
        }
        .form-control:focus {
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
            border-color: #86b7fe;
        }
        .btn-gradient {
            background: linear-gradient(45deg, #2b5876 0%, #4e4376 100%);
            color: white;
            border-radius: 10px;
            border: none;
            transition: all 0.3s ease;
        }
        .btn-gradient:hover {
            background: linear-gradient(45deg, #1a3648 0%, #312a4a 100%);
            box-shadow: 0 8px 20px rgba(78, 67, 118, 0.4);
            color: white;
            transform: scale(1.02);
        }
        .file-upload-wrapper {
            position: relative;
            border: 2px dashed #adb5bd;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            background: #f8f9fa;
            transition: 0.3s;
        }
        .file-upload-wrapper:hover { border-color: #2b5876; background: #e9ecef; }
    </style>
</head>
<body class="d-flex align-items-center py-5">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-6">
            <div class="text-center mb-4">
                <h2 class="fw-bold text-dark" style="letter-spacing: 1px;">
                    <i class="bi bi-robot text-primary"></i> ARCH.AI
                </h2>
                <p class="text-muted">Sistem Evaluasi Properti Multimodal</p>
            </div>

            <div class="card glass-card p-4 p-md-5 text-center">
    <h3 class="fw-bold mb-3">Apa itu Arch.AI?</h3>
    <p class="text-muted mb-4">
        Arch.AI adalah sistem evaluasi properti cerdas yang menggabungkan analisis 
        visual komputer dan pemodelan statistik untuk memberikan estimasi harga 
        yang akurat dan transparan.
    </p>

    <div class="row text-start mb-4">
        <div class="col-12 mb-2"><i class="bi bi-check2-circle text-primary me-2"></i>Analisis Gambar Real-time</div>
        <div class="col-12 mb-2"><i class="bi bi-check2-circle text-primary me-2"></i>Prediksi Harga Berbasis AI</div>
        <div class="col-12 mb-2"><i class="bi bi-check2-circle text-primary me-2"></i>Integrasi Geotagging Lokasi</div>
    </div>

    <a href="kalkulator.php" class="btn btn-gradient w-100 fw-bold py-3 fs-6">
        <i class="bi bi-calculator me-2"></i> HITUNG SEKARANG
    </a>
</div>
        </div>
    </div>
</div>
</body>
</html>