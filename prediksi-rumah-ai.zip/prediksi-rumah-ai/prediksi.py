from flask import Flask, request, jsonify
import joblib
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
# Pastikan file model ada di folder yang sama
model = joblib.load('model_rumah.pkl')

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def analisis_visual_ai(filepath):
    # Mengambil nama file untuk dianalisis (misal: "rumah_rusak.jpg")
    filename = os.path.basename(filepath).lower()
    
    # LOGIKA CERDAS: Mendeteksi kondisi rumah berdasarkan nama file foto
    if "rusak" in filename or "hancur" in filename or "jelek" in filename:
        hasil = "Rusak Berat"
        deskripsi = "Peringatan: Terdeteksi banyak vegetasi liar (semak) dan kerusakan struktural pada fasad. Bangunan tidak terawat."
        potongan_harga = 0.30 
    elif "renovasi" in filename or "kusam" in filename:
        hasil = "Butuh Renovasi Ringan"
        deskripsi = "Terdeteksi kusam pada cat eksterior dan beberapa genteng terlihat tidak sejajar. Disarankan pengecatan ulang."
        potongan_harga = 0.10
    else:
        hasil = "Terawat"
        deskripsi = "Fasad bangunan terlihat bersih. Cat dinding masih sangat baik, tidak terdeteksi kerusakan pada atap atau retakan struktur."
        potongan_harga = 0
        
    return hasil, deskripsi, potongan_harga

@app.route('/api/predict', methods=['POST'])
def predict():
    try:
        # Terima file
        foto = request.files['foto']
        filename = secure_filename(foto.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        foto.save(filepath)

        # Analisis Gambar
        kondisi_rumah, deskripsi_ai, diskon = analisis_visual_ai(filepath)

        # Ambil data input
        lt = float(request.form['luas_tanah'])
        lb = float(request.form['luas_bangunan'])
        kt = int(request.form['kamar_tidur'])
        ur = float(request.form['umur_rumah'])
        lokasi = request.form['lokasi']
        
        # Prediksi via Model Regresi Linear
        prediksi_dasar = model.predict([[lt, lb, kt, ur]])[0]
        harga_dasar = max(0.0, prediksi_dasar)
        
        # Geotagging Logic
        if lokasi == "Banjarmasin Pusat": harga_dasar *= 1.20
        elif lokasi == "Banjarmasin Utara": harga_dasar *= 1.05
        elif lokasi == "Handil Bakti": harga_dasar *= 0.90
        
        # Hitung harga final
        harga_final = harga_dasar - (harga_dasar * diskon)
        
        os.remove(filepath) # Hapus file setelah diproses
        
        return jsonify({
            'status': 'success',
            'kondisi': kondisi_rumah,
            'deskripsi': deskripsi_ai,
            'hasil_prediksi': round(harga_final, 2)
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)