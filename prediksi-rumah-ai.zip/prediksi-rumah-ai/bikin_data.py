import pandas as pd
import os

# 1. Membuat data dummy rumah
data_rumah = {
    'luas_tanah': [120, 90, 150, 200, 80, 110, 250, 300, 70, 100],
    'luas_bangunan': [100, 60, 120, 150, 50, 90, 200, 250, 45, 80],
    'kamar_tidur': [3, 2, 4, 4, 2, 3, 5, 5, 2, 3],
    'umur_rumah': [5, 2, 10, 15, 3, 7, 20, 10, 1, 4],
    'harga': [850000000, 500000000, 1200000000, 1500000000, 400000000, 750000000, 2000000000, 2500000000, 350000000, 600000000]
}

# 2. Mengubahnya jadi format tabel
df = pd.DataFrame(data_rumah)

# 3. Membuat folder 'data' secara otomatis jika belum ada
os.makedirs('data', exist_ok=True)

# 4. Menyimpan jadi file Excel
df.to_excel('data/dataset_rumah.xlsx', index=False)

print("Berhasil! Folder 'data' dan file 'dataset_rumah.xlsx' sudah otomatis dibuat.")