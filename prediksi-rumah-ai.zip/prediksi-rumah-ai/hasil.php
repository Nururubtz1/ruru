<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['foto_rumah'])) {
    
    $foto_tmp = $_FILES['foto_rumah']['tmp_name'];
    $foto_name = $_FILES['foto_rumah']['name'];
    $foto_type = $_FILES['foto_rumah']['type'];
    $cfile = new CURLFile($foto_tmp, $foto_type, $foto_name);

    $post_data = array(
        'foto' => $cfile,
        'luas_tanah' => $_POST['luas_tanah'],
        'luas_bangunan' => $_POST['luas_bangunan'],
        'kamar_tidur' => $_POST['kamar_tidur'],
        'umur_rumah' => $_POST['umur_rumah'],
        'lokasi' => $_POST['lokasi']
    );

    $ch = curl_init('http://127.0.0.1:5000/api/predict');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    
    if(isset($result['status']) && $result['status'] == 'success'){
        $harga_final = number_format($result['hasil_prediksi'], 0, ',', '.');
        $kondisi = $result['kondisi'];
        $deskripsi = $result['deskripsi'];
        
        // --- SIMPAN KE DATABASE ---
        $conn = mysqli_connect("localhost", "root", "", "db_prediksi_rumah");
        $lt = $_POST['luas_tanah'];
        $lb = $_POST['luas_bangunan'];
        $kt = $_POST['kamar_tidur'];
        $ur = $_POST['umur_rumah'];
        $lok = $_POST['lokasi'];
        $harga_db = str_replace('.', '', $harga_final); 
        
        $query_simpan = "INSERT INTO riwayat_prediksi (lokasi, luas_tanah, luas_bangunan, kamar_tidur, umur_rumah, harga_prediksi) 
                         VALUES ('$lok', '$lt', '$lb', '$kt', '$ur', '$harga_db')";
        mysqli_query($conn, $query_simpan);

        // Warna Badge Kondisi
        if ($kondisi == 'Terawat') { $badge_color = 'bg-success'; $icon = 'bi-check-circle-fill'; } 
        elseif ($kondisi == 'Butuh Renovasi Ringan') { $badge_color = 'bg-warning text-dark'; $icon = 'bi-exclamation-triangle-fill'; } 
        else { $badge_color = 'bg-danger'; $icon = 'bi-x-octagon-fill'; }
    } else {
        echo "Error: " . $result['message']; exit;
    }
} else {
    header("Location: index.php"); exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Hasil Laporan Properti</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background-color: #0f172a; color: #f8fafc; font-family: 'Segoe UI', sans-serif; }
        .result-card { background: #1e293b; border-radius: 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.4); border: 1px solid #334155; }
        .price-box { background: linear-gradient(135deg, #10b981 0%, #059669 100%); border-radius: 15px; padding: 20px; color: white; }
        .feature-item { background: #334155; border-radius: 10px; padding: 10px; text-align: center; }
        .btn-back { background: transparent; color: #94a3b8; border: 2px solid #475569; border-radius: 10px; }
        .btn-back:hover { background: #475569; color: white; }
    </style>
</head>
<body class="py-5">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="result-card p-5">
                <h3 class="fw-bold text-center mb-4"><i class="bi bi-file-earmark-text me-2"></i>Laporan Inspeksi AI</h3>
                
                <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom border-secondary">
                    <h5 class="m-0"><i class="bi bi-eye me-2"></i>Status Fisik:</h5>
                    <span class="badge <?php echo $badge_color; ?> rounded-pill px-3 py-2"><i class="bi <?php echo $icon; ?> me-1"></i> <?php echo $kondisi; ?></span>
                </div>

                <p class="text-muted small fw-bold">ANALISIS VISUAL:</p>
                <div class="p-3 bg-dark rounded-3 border border-secondary mb-4"><?php echo $deskripsi; ?></div>

                <div class="row g-2 mb-4">
                    <div class="col-6"><div class="feature-item"><small class="text-muted">Wilayah</small><br><strong><?php echo $_POST['lokasi']; ?></strong></div></div>
                    <div class="col-6"><div class="feature-item"><small class="text-muted">Luas Tanah</small><br><strong><?php echo $_POST['luas_tanah']; ?> m²</strong></div></div>
                </div>

                <div class="price-box text-center">
                    <p class="mb-1 opacity-75">Estimasi Valuasi Final</p>
                    <h1 class="fw-bold mb-0">Rp <?php echo $harga_final; ?></h1>
                </div>

                <div class="row g-2 mt-4 d-print-none">
                    <div class="col-6"><button onclick="window.print()" class="btn btn-outline-info w-100 py-3 fw-bold">CETAK PDF</button></div>
                    <div class="col-6"><a href="index.php" class="btn btn-back w-100 py-3 fw-bold">KEMBALI</a></div>
                </div>
                <div class="text-center mt-3 d-print-none">
                    <a href="riwayat.php" class="text-muted text-decoration-none small">Lihat Riwayat Analisis</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>