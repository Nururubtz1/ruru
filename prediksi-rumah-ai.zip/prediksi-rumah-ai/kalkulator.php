<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arch.AI - Kalkulator Properti</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; }
        .glass-card { background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(10px); border-radius: 20px; border: 1px solid rgba(255, 255, 255, 0.5); box-shadow: 0 15px 35px rgba(0,0,0,0.1); }
        .btn-gradient { background: linear-gradient(45deg, #2b5876 0%, #4e4376 100%); color: white; border-radius: 10px; border: none; }
        .file-upload-wrapper { border: 2px dashed #adb5bd; border-radius: 10px; padding: 20px; text-align: center; background: #f8f9fa; }
        .form-control { border-radius: 10px; padding: 12px; }
    </style>
</head>
<body class="d-flex align-items-center py-5">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-6">
            <div class="card glass-card p-4 p-md-5">
                <h4 class="mb-4 fw-bold text-center"><i class="bi bi-robot me-2"></i>Analisis Properti</h4>
                
                <form action="hasil.php" method="POST" enctype="multipart/form-data">
                    
                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark"><i class="bi bi-camera me-2"></i>Upload Foto Depan Rumah</label>
                        <div class="file-upload-wrapper">
                            <input type="file" class="form-control border-0 bg-transparent" name="foto_rumah" accept="image/*" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold text-muted small"><i class="bi bi-geo-alt me-2"></i>LOKASI PROPERTI</label>
                        <select class="form-select" name="lokasi" required>
                            <option value="" disabled selected>Pilih Wilayah...</option>
                            <option value="Banjarmasin Pusat">Banjarmasin Pusat</option>
                            <option value="Banjarmasin Utara">Banjarmasin Utara</option>
                            <option value="Handil Bakti">Handil Bakti</option>
                        </select>
                    </div>

                    <div class="row mb-3">
                        <div class="col-6">
                            <label class="form-label fw-semibold text-muted small">LUAS TANAH (m²)</label>
                            <input type="number" class="form-control" name="luas_tanah" placeholder="120" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-semibold text-muted small">LUAS BANGUNAN (m²)</label>
                            <input type="number" class="form-control" name="luas_bangunan" placeholder="90" required>
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-6">
                            <label class="form-label fw-semibold text-muted small">KAMAR TIDUR</label>
                            <input type="number" class="form-control" name="kamar_tidur" placeholder="3" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-semibold text-muted small">UMUR (TAHUN)</label>
                            <input type="number" class="form-control" name="umur_rumah" placeholder="5" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-gradient w-100 py-3 fw-bold">
                        <i class="bi bi-magic me-2"></i> MULAI ANALISIS AI
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>