import pandas as pd
from sklearn.linear_model import LinearRegression
import joblib

# Lokasi file excel yang kamu buat tadi
file_path = 'data/dataset_rumah.xlsx'

print("Membaca dataset Excel...")
df = pd.read_excel(file_path, engine='openpyxl')

# Pembersihan Data (hapus baris yang kosong)
df = df.dropna()

# Memisahkan Fitur (X) dan Target Harga (y)
X = df[['luas_tanah', 'luas_bangunan', 'kamar_tidur', 'umur_rumah']]
y = df['harga']

# Proses Belajar / Training AI
print("Sedang melatih model AI...")
model = LinearRegression()
model.fit(X, y)

# Menyimpan 'Otak' AI yang sudah pintar
joblib.dump(model, 'model_rumah.pkl')
print("Sukses! Model AI berhasil disimpan sebagai 'model_rumah.pkl'")